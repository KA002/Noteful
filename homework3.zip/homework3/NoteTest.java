package com.example.myapplication;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class NoteTest {

    String FAKE_TITLE;
    String FAKE_ADDRESS;
    Note note = new Note();

    public NoteTest() throws IOException {
    }
    @Before
    public void setUp() throws Exception {
        String fileName = "src/test/java/com/example/myapplication/Testcases/NotetestCases";
        Path path = Paths.get(fileName);
        Scanner scanner = new Scanner(path);
        if((scanner.hasNextLine())){
            String line = scanner.nextLine();
            String[] line_split = line.split("\\s+");
            FAKE_TITLE = line_split[0];
            FAKE_ADDRESS = line_split[1];
        }
        note.setAddress(FAKE_ADDRESS);
        note.setTitle(FAKE_TITLE);
    }
    @Test
    public void getAddressRight(){
        String TEST_ADDRESS = note.getAddress();
        Assert.assertEquals(FAKE_ADDRESS,TEST_ADDRESS);
    }
    @Test
    public void getTitleRight(){
        String TEST_TITLE = note.getTitle();
        Assert.assertEquals(FAKE_TITLE,TEST_TITLE);
    }

}
